if __name__ == '__main__':
    try:
        raise RuntimeError()
    except:
        print('TEST SUCEEDED!')
